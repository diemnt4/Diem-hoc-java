package javaDay1;

public class Ex1_HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello world");
	}

}
